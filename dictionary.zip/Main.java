/*interger (int) refers to one number without a single decimal, will automatically round up */


class Main {
  public static void main(String[] args) {
    int bruh = 1;

    bruh += 2;
    bruh %= 3;
    /*the addition symbol and module symbol before the equal symbol will do said operation and set it as the value for the variable*/ 

    System.out.println(bruh);
    
    String dictionary = 

    System.out.println(dictionary);

  }
}