class Main ninePlusTen{
  public static void main(String[] args) {
    if 






    System.out.println("Hello world!");
  }
}